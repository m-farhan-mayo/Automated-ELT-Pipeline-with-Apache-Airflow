from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.bash import BashOperator


default_args = {
    'owner' : 'farhanmayo',
    'retries' : 5,
    'retry_delay' : timedelta(minutes=2)
}

with DAG(
    default_args = default_args,
    dag_id = 'dag_with_cron_expression_v1',
    start_date = datetime(2021,11,1),
    schedule = '0 8 * * 1' 

)as dag:
    task1 =BashOperator(
        task_id = 'task1',
        bash_command = "echo 'This Is DAG With Cron Expression'"
    )