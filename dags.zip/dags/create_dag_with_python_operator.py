from airflow import DAG
from datetime import datetime , timedelta
from airflow.providers.standard.operators.python import PythonOperator
default_args = {
    'owner' : "farhanmayo",
    'retries' : 5,
    'retry_delay' : timedelta(minutes=2)

}



def greeting(ti):
    first_name = ti.xcom_pull(task_ids="get_name", key = "first_name")
    last_name = ti.xcom_pull(task_ids="get_name", key = "last_name")
    age = ti.xcom_pull(task_ids="get_age", key = "age")
    print(f"Assalam-o-Alakium!, My Name Is {first_name} {last_name} And {age} Years Old")

def get_name():
    return 'MaYo'

def get_name(ti):
    ti.xcom_push(key='first_name', value='Farhan')
    ti.xcom_push(key='last_name', value='MaYo')

def get_age(ti):
    ti.xcom_push(key='age', value= 23)

with DAG(
    default_args = default_args,
    dag_id = "create_dag_with_python_operator_v6",
    description = "This Is My First Python Operator DAG",
    start_date = datetime(2021,1,1),
    schedule = '@daily' 

) as dag:
    task1 = PythonOperator(
        task_id = "python_task",
        python_callable = greeting
        # op_kwargs = {'age':23}
    )
    task2 = PythonOperator(
        task_id = "get_name",
        python_callable = get_name
    )
    task3 = PythonOperator(
        task_id= "get_age",
        python_callable = get_age
    )


    [task2,task3] >> task1