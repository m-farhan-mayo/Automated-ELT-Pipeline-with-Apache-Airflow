from airflow import DAG
from datetime import datetime , timedelta
from airflow.providers.standard.operators.bash import BashOperator


default_args = {
    'owner' : "farhanmayo",
    'retries' : 5,
    'retry_delay' : timedelta(minutes=2)

}

with DAG(
    dag_id = "our_first_dag_v3",
    default_args = default_args,
    description = "This Is My First DAG",
    start_date = datetime(2021,1,1 , 2),
    schedule = '@daily' 

) as dag:
    task1 = BashOperator(
        task_id = "first_task",
        bash_command = "echo 'Hi MaYo ! This Is The First Task'"
    )
    task2 = BashOperator(
        task_id = "Second_task",
        bash_command = "echo 'Second Task ! Be Second After First'"
    )
    task3 = BashOperator(
        task_id = "Third_task",
        bash_command = "echo 'Third Task ! Be First After First & Second'"
    )


    task1>>[task2,task3]
